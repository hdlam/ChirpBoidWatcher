package no.ntnu.idi.chirp;

public interface MulticastListener
{
	public void multiCastRecieved(String data);
}
