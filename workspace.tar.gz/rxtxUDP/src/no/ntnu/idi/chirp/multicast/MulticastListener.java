package no.ntnu.idi.chirp.multicast;

public interface MulticastListener
{
	public void multiCastRecieved();
}
